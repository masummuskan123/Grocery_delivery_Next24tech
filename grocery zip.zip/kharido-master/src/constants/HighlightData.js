export const HighlightData = [
  {
    heading: 'Up to 50% OFF on Gubb',
    subHeadings: 'Hair Pins,Eye Masks & more',
    backcolor: 'pink',
    textcolor: 'black',
    path: require('../images/slider/5.jpeg'),
  },
  {
    heading: 'Gifts that make moments happier',
    subHeadings: 'Get perfume Sets, Skin Care Kits & more',
    backcolor: 'yellow',
    textcolor: 'black',
    path: require('../images/slider/a.jpeg'),
  },
  {
    heading: 'Up to 40% OFF on Swiss Beauty ',
    subHeadings: 'Get a free gift on orders above 499',
    backcolor: 'red',
    textcolor: 'white',
    path: require('../images/slider/3.jpeg'),
  },
  {
    heading: 'Glam Party 17th - 27th august ',
    subHeadings: 'Up to 60% OFF on top beauty brands',
    textcolor: 'white',
    backcolor: '#fc03f8',
    path: require('../images/slider/4.jpeg'),
  },
];


