export const headerData = [
    {
        "heading": "Chocolate Hampers",
        "path" : require('../images/chocolate.png')
    },
    {
        "heading": "Indian Sweets",
        "path" : require('../images/gulab.png')
    },
    {
        "heading": "Gifting Essentials",
        "path" : require('../images/phone.png')
    },
    {
        "heading": "Dry Fruit gift packs",
        "path" : require('../images/dryfruit.png')
    },
    {
        "heading": "Pooja needs",
        "path" : require('../images/poojs.png')
    },
    {
        "heading": "Party needs",
        "path" : require('../images/party.png')
    },
    {
        "heading": "Festive needs",
        "path" : require('../images/festive.png')
    },
];