export const AllCategoryProducts = [
  {
    'category': 'Dairy & Breakfast',
    products: [
      {name: 'Milk', path: require('../images/DairyBreakfast/milk.png')},
      {name: "Breads & pav" , path: require("../images/DairyBreakfast/bread.png")},
      {name:"Eggs",path :require("../images/DairyBreakfast/eggs.png") },
      {name:"Oats", path: require("../images/DairyBreakfast/oats.png")},
      {name:"Panner & tofu", path: require("../images/DairyBreakfast/panner.png")},
      {name:"Curd & yoghurt", path: require("../images/DairyBreakfast/curd.png")},
      {name:"Cheese", path: require("../images/DairyBreakfast/cheese.png")},
      {name:"Butter", path: require("../images/DairyBreakfast/butter.png")},
    ]
  },
];
